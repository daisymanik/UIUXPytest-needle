"""pytest_needle

.. codeauthor:: John Lane <jlane@fanthreesixty.com>

"""

__author__ = 'jlane'
__email__ = 'jlane@fanthreesixty.com'
__license__ = 'MIT'
__version__ = '0.3.11'
